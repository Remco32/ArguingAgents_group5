This zip file contains our proposal, a python script and a json file.

The python script is what we have used to generate the output file. This file contains the pro and con arguments about medical marijuana, mined from procon.org.